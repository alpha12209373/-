const { onCall, HttpsError } = require("firebase-functions/v2/https");
const { defineSecret } = require("firebase-functions/params");
const admin = require("firebase-admin");

admin.initializeApp();
const OPENAI_API_KEY = defineSecret("OPENAI_API_KEY");

exports.generateStudyContent = onCall(
  { secrets: [OPENAI_API_KEY], timeoutSeconds: 120, memory: "512MiB" },
  async (request) => {
    if (!request.auth) {
      throw new HttpsError("unauthenticated", "يجب تسجيل الدخول أولاً.");
    }

    const { task, title = "", content = "" } = request.data || {};
    if (!["summarize", "quiz", "chat"].includes(task)) {
      throw new HttpsError("invalid-argument", "نوع الطلب غير مدعوم.");
    }
    if (typeof content !== "string" || content.trim().length < 2 || content.length > 50000) {
      throw new HttpsError("invalid-argument", "النص فارغ أو أطول من الحد المسموح.");
    }

    let instructions;
    if (task === "summarize") {
      instructions = "أنت مساعد أكاديمي عربي. لخّص النص الدراسي باللغة العربية الواضحة وبالتفصيل المناسب. استخدم عناوين فرعية ونقاطاً، وعرّف المصطلحات، واحتفظ بالمعلومات المهمة دون اختراع معلومات غير موجودة. إذا كان النص ناقصاً فاذكر ذلك.";
    } else if (task === "quiz") {
      instructions = "أنشئ 10 أسئلة تدريبية باللغة العربية اعتماداً حصراً على المادة. نوّع بين اختيار من متعدد وصح وخطأ وأسئلة قصيرة. ضع الإجابة الصحيحة وشرحاً موجزاً بعد كل سؤال. لا تخترع معلومات خارج النص.";
    } else {
      instructions = "أنت مساعد جامعي عراقي ودود. أجب بالعربية الواضحة وبأسلوب مبسط، واشرح خطوة بخطوة عند الحاجة. إذا كان السؤال خارج الدراسة فأجب باختصار. لا تخترع حقائق.";
    }

    const input = task === "chat"
      ? content
      : `العنوان: ${title}\n\nالمادة الدراسية:\n${content}`;

    try {
      const response = await fetch("https://api.openai.com/v1/responses", {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${OPENAI_API_KEY.value()}`,
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          model: "gpt-4.1-mini",
          instructions,
          input,
          max_output_tokens: task === "summarize" ? 5000 : 3000
        })
      });

      const data = await response.json();
      if (!response.ok) {
        console.error("OpenAI error", data);
        throw new Error("AI provider request failed");
      }

      let result = "";
      for (const item of (data.output || [])) {
        if (item.type === "message") {
          for (const part of (item.content || [])) {
            if (part.type === "output_text") result += part.text;
          }
        }
      }
      if (!result) throw new Error("Empty AI response");

      await admin.firestore().collection("users").doc(request.auth.uid)
        .collection("ai_usage").add({
          task, createdAt: admin.firestore.FieldValue.serverTimestamp()
        });

      return { result };
    } catch (error) {
      console.error(error);
      throw new HttpsError("internal", "تعذر إنشاء المحتوى حالياً. حاول لاحقاً.");
    }
  }
);

// Redeem a one-device premium code. The transaction prevents two devices
// from claiming the same code at the same time.
exports.redeemPremiumCode = onCall(async (request) => {
  if (!request.auth) throw new HttpsError("unauthenticated", "سجّل الدخول أولاً.");
  const code = String(request.data?.code || "").trim().toUpperCase();
  const deviceId = String(request.data?.deviceId || "");
  if (!/^[A-Z0-9-]{8,40}$/.test(code) || deviceId.length < 5 || deviceId.length > 200) {
    throw new HttpsError("invalid-argument", "الكود أو معرّف الجهاز غير صحيح.");
  }
  const db = admin.firestore();
  const codeRef = db.collection("premium_codes").doc(code);
  const userRef = db.collection("users").doc(request.auth.uid);
  return db.runTransaction(async (tx) => {
    const [codeSnap, userSnap] = await Promise.all([tx.get(codeRef), tx.get(userRef)]);
    if (!codeSnap.exists) throw new HttpsError("not-found", "كود التفعيل غير صحيح.");
    const item = codeSnap.data();
    if (item.disabled === true) throw new HttpsError("failed-precondition", "هذا الكود متوقف.");
    if (item.deviceId && item.deviceId !== deviceId) throw new HttpsError("already-exists", "هذا الكود مستخدم على جهاز آخر.");
    if (item.usedBy && item.usedBy !== request.auth.uid) throw new HttpsError("already-exists", "هذا الكود مستخدم مسبقاً.");
    if (item.expiresAt && item.expiresAt.toDate() < new Date()) throw new HttpsError("deadline-exceeded", "انتهت صلاحية هذا الكود.");
    const days = Math.max(1, Math.min(Number(item.durationDays || 30), 3650));
    const now = admin.firestore.Timestamp.now();
    const oldUntil = userSnap.data()?.premiumUntil?.toDate?.();
    const base = oldUntil && oldUntil > now.toDate() ? oldUntil : now.toDate();
    const until = admin.firestore.Timestamp.fromDate(new Date(base.getTime() + days * 86400000));
    tx.set(codeRef, { deviceId, usedBy: request.auth.uid, usedAt: now }, { merge: true });
    tx.set(userRef, { premium: true, premiumDeviceId: deviceId, premiumUntil: until }, { merge: true });
    return { ok: true, message: `تم تفعيل جامعتي المميز لمدة ${days} يوم.` };
  });
});

// Admin-only code generator. Set the Firebase Auth custom claim {admin:true}
// on your own account before calling this function from a private admin tool.
exports.createPremiumCodes = onCall(async (request) => {
  if (!request.auth || request.auth.token.admin !== true) {
    throw new HttpsError("permission-denied", "هذه العملية للمسؤول فقط.");
  }
  const count = Math.max(1, Math.min(Number(request.data?.count || 1), 100));
  const durationDays = Math.max(1, Math.min(Number(request.data?.durationDays || 30), 3650));
  const db = admin.firestore();
  const codes = [];
  for (let i = 0; i < count; i++) {
    const code = `JAMIATI-${require('crypto').randomBytes(5).toString('hex').toUpperCase()}`;
    await db.collection('premium_codes').doc(code).create({
      durationDays, createdAt: admin.firestore.FieldValue.serverTimestamp(),
      usedBy: null, deviceId: null, disabled: false
    });
    codes.push(code);
  }
  return { codes };
});

// Maintain anonymous aggregate counts; the app never needs to read student records.
const { onDocumentWritten } = require("firebase-functions/v2/firestore");
exports.updateStudentCounts = onDocumentWritten("users/{uid}", async (event) => {
  const before = event.data?.before?.exists ? event.data.before.data() : null;
  const after = event.data?.after?.exists ? event.data.after.data() : null;
  if (!before && !after) return;
  const oldSpecialty = before?.specialty || null;
  const newSpecialty = after?.specialty || null;
  if (oldSpecialty === newSpecialty && !!before === !!after) return;
  const db = admin.firestore();
  await db.runTransaction(async (tx) => {
    const ref = db.collection("public_stats").doc("students");
    const snap = await tx.get(ref);
    const stats = snap.data() || { total: 0, bySpecialty: {} };
    const by = { ...(stats.bySpecialty || {}) };
    let total = Number(stats.total || 0);
    if (!before && after) total += 1;
    if (before && !after) total = Math.max(0, total - 1);
    if (oldSpecialty && oldSpecialty !== newSpecialty) by[oldSpecialty] = Math.max(0, Number(by[oldSpecialty] || 0) - 1);
    if (newSpecialty && oldSpecialty !== newSpecialty) by[newSpecialty] = Number(by[newSpecialty] || 0) + 1;
    tx.set(ref, { total, bySpecialty: by, updatedAt: admin.firestore.FieldValue.serverTimestamp() }, { merge: true });
  });
});
