import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:cloud_functions/cloud_functions.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:android_id/android_id.dart';

const purple = Color(0xFF7652D6);
const darkPurple = Color(0xFF4D32A5);
const bg = Color(0xFFF7F5FC);
const specialties = <String>[
  'الطب', 'طب الأسنان', 'الصيدلة', 'التمريض', 'الهندسة', 'هندسة الحاسوب',
  'تقنيات المعلومات', 'علوم الحاسوب', 'القانون', 'الإدارة والاقتصاد',
  'التربية', 'العلوم', 'الآداب', 'الزراعة', 'الفنون الجميلة', 'أخرى'
];

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  var ready = false;
  try {
    await Firebase.initializeApp();
    ready = true;
  } catch (e) {
    debugPrint('Firebase initialization: $e');
  }
  runApp(JamiatiApp(firebaseReady: ready));
}

class JamiatiApp extends StatelessWidget {
  final bool firebaseReady;
  const JamiatiApp({super.key, required this.firebaseReady});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'جامعتي', debugShowCheckedModeBanner: false, locale: const Locale('ar'),
    supportedLocales: const [Locale('ar')],
    localizationsDelegates: GlobalMaterialLocalizations.delegates,
    theme: ThemeData(useMaterial3: true, scaffoldBackgroundColor: bg,
      colorScheme: ColorScheme.fromSeed(seedColor: purple),
      appBarTheme: const AppBarTheme(backgroundColor: bg, foregroundColor: Color(0xFF241B3D), elevation: 0),
      inputDecorationTheme: const InputDecorationTheme(border: OutlineInputBorder(), filled: true, fillColor: Colors.white),
    ),
    builder: (context, child) => Directionality(textDirection: TextDirection.rtl, child: child ?? const SizedBox.shrink()),
    home: firebaseReady ? const AuthGate() : const FirebaseSetupScreen(),
  );
}

class FirebaseSetupScreen extends StatelessWidget {
  const FirebaseSetupScreen({super.key});
  @override Widget build(BuildContext context) => const Scaffold(body: Center(child: Padding(padding: EdgeInsets.all(24), child: Column(mainAxisSize: MainAxisSize.min, children: [
    Icon(Icons.school, color: purple, size: 64), SizedBox(height: 14), Text('جامعتي', style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold, color: darkPurple)),
    SizedBox(height: 12), Text('المشروع جاهز للربط، لكن إعداد Firebase غير موجود بعد. أضف ملفات إعداد Android و iOS واتبع ملف README_AR.md لتفعيل تسجيل Google وقاعدة البيانات.', textAlign: TextAlign.center, style: TextStyle(height: 1.7)),
  ]))));
}

class AuthGate extends StatelessWidget {
  const AuthGate({super.key});
  @override Widget build(BuildContext context) => StreamBuilder<User?>(
    stream: FirebaseAuth.instance.authStateChanges(),
    builder: (context, snapshot) {
      if (snapshot.connectionState == ConnectionState.waiting) return const Scaffold(body: Center(child: CircularProgressIndicator()));
      final user = snapshot.data;
      if (user == null) return const LoginScreen();
      return FutureBuilder<DocumentSnapshot<Map<String, dynamic>>>(
        future: FirebaseFirestore.instance.collection('users').doc(user.uid).get(),
        builder: (context, profile) {
          if (profile.hasError) return const Scaffold(body: Center(child: Padding(padding: EdgeInsets.all(24), child: Text('تعذر تحميل بيانات الحساب. تحقق من اتصال الإنترنت وإعدادات Firestore.', textAlign: TextAlign.center))));
          if (!profile.hasData) return const Scaffold(body: Center(child: CircularProgressIndicator()));
          final data = profile.data!.data() ?? {};
          final specialty = data['specialty'] as String?;
          if (specialty == null || specialty.isEmpty) return SpecialtyScreen(user: user);
          return MainShell(user: user, profile: data);
        });
    });
}

class LoginScreen extends StatefulWidget { const LoginScreen({super.key}); @override State<LoginScreen> createState()=>_LoginScreenState(); }
class _LoginScreenState extends State<LoginScreen> {
  bool loading = false;
  Future<void> signIn() async {
    setState(()=>loading=true);
    try {
      final googleUser = await GoogleSignIn().signIn();
      if (googleUser == null) { setState(()=>loading=false); return; }
      final googleAuth = await googleUser.authentication;
      final credential = GoogleAuthProvider.credential(accessToken: googleAuth.accessToken, idToken: googleAuth.idToken);
      final result = await FirebaseAuth.instance.signInWithCredential(credential);
      final user = result.user!;
      await FirebaseFirestore.instance.collection('users').doc(user.uid).set({
        'name': user.displayName ?? 'طالب', 'photoUrl': user.photoURL ?? '', 'email': user.email ?? '',
        'createdAt': FieldValue.serverTimestamp(), 'lastSeen': FieldValue.serverTimestamp(),
      }, SetOptions(merge:true));
    } catch (e) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('تعذر تسجيل الدخول: $e'))); }
    if (mounted) setState(()=>loading=false);
  }
  @override Widget build(BuildContext context)=>Scaffold(body:SafeArea(child:Center(child:SingleChildScrollView(padding:const EdgeInsets.all(24),child:ConstrainedBox(constraints:const BoxConstraints(maxWidth:440),child:Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
    const CircleAvatar(radius:48,backgroundColor:purple,child:Icon(Icons.school,color:Colors.white,size:52)), const SizedBox(height:20),
    const Text('جامعتي',textAlign:TextAlign.center,style:TextStyle(fontSize:36,fontWeight:FontWeight.w900,color:darkPurple)),
    const Text('كل حياتك الجامعية بمكان واحد',textAlign:TextAlign.center),const SizedBox(height:34),
    FilledButton.icon(onPressed:loading?null:signIn,icon:const Icon(Icons.login),label:Padding(padding:const EdgeInsets.all(14),child:Text(loading?'جارٍ تسجيل الدخول...':'تسجيل الدخول باستخدام Google'))),
    const SizedBox(height:14),const Text('سجّل دخولك بحساب Google، ثم اختر تخصصك وابدأ رحلتك الجامعية.',textAlign:TextAlign.center,style:TextStyle(color:Colors.black54,height:1.6)),
  ]))))));
}

class SpecialtyScreen extends StatefulWidget { final User user; const SpecialtyScreen({super.key,required this.user}); @override State<SpecialtyScreen> createState()=>_SpecialtyScreenState(); }
class _SpecialtyScreenState extends State<SpecialtyScreen> {
  String? selected; bool saving=false;
  Future<void> save() async { if(selected==null)return; setState(()=>saving=true); await FirebaseFirestore.instance.collection('users').doc(widget.user.uid).set({'specialty':selected,'name':widget.user.displayName??'طالب','photoUrl':widget.user.photoURL??''},SetOptions(merge:true)); if(mounted)setState(()=>saving=false); }
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('اختر تخصصك')),body:ListView(padding:const EdgeInsets.all(20),children:[
    const Text('أهلاً بيك في جامعتي 👋',style:TextStyle(fontSize:24,fontWeight:FontWeight.bold,color:darkPurple)),const SizedBox(height:8),const Text('حتى نعرض لك إحصائيات الطلاب المناسبة، اختار تخصصك الجامعي.'),const SizedBox(height:20),
    ...specialties.map((s)=>Card(child:RadioListTile<String>(value:s,groupValue:selected,title:Text(s),activeColor:purple,onChanged:(v)=>setState(()=>selected=v)))),const SizedBox(height:12),
    FilledButton(onPressed:selected==null||saving?null:save,child:Text(saving?'جارٍ الحفظ...':'متابعة')),
  ]));
}

class MainShell extends StatefulWidget {
  final User user; final Map<String,dynamic> profile;
  const MainShell({super.key,required this.user,required this.profile});
  @override State<MainShell> createState()=>_MainShellState();
}
class _MainShellState extends State<MainShell> {
  int index=0; final summaries=<String>[]; final schedule=<Map<String,String>>[];
  @override Widget build(BuildContext context){
    final name=(widget.profile['name'] as String?)?.trim().isNotEmpty==true?widget.profile['name'] as String:widget.user.displayName??'طالب';
    final pages=[HomeScreen(name:name,summaries:summaries,specialty:widget.profile['specialty']??'غير محدد'),SummarizeScreen(onSave:(s)=>setState(()=>summaries.insert(0,s))),const QuizScreen(),const AssistantScreen(),ScheduleScreen(items:schedule,onChanged:()=>setState((){}))];
    const titles=['الرئيسية','تلخيص الملازم','الاختبارات','المساعد الدراسي','جدولي'];
    return Scaffold(appBar:AppBar(title:Text(titles[index],style:const TextStyle(fontWeight:FontWeight.bold)),actions:[IconButton(tooltip:'الملف الشخصي',onPressed:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>ProfileScreen(user:widget.user,profile:widget.profile))),icon:const Icon(Icons.account_circle_outlined)),IconButton(tooltip:'الإعدادات',onPressed:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>SettingsScreen(user:widget.user))),icon:const Icon(Icons.settings_outlined))]),
      body:IndexedStack(index:index,children:pages),bottomNavigationBar:NavigationBar(selectedIndex:index,onDestinationSelected:(v)=>setState(()=>index=v),destinations:const [NavigationDestination(icon:Icon(Icons.home_outlined),label:'الرئيسية'),NavigationDestination(icon:Icon(Icons.summarize_outlined),label:'تلخيص'),NavigationDestination(icon:Icon(Icons.quiz_outlined),label:'اختبرني'),NavigationDestination(icon:Icon(Icons.auto_awesome_outlined),label:'اسألني'),NavigationDestination(icon:Icon(Icons.calendar_month_outlined),label:'الجدول')]));
  }
}

class ProfileScreen extends StatefulWidget { final User user; final Map<String,dynamic> profile; const ProfileScreen({super.key,required this.user,required this.profile}); @override State<ProfileScreen> createState()=>_ProfileScreenState(); }
class _ProfileScreenState extends State<ProfileScreen>{late final name=TextEditingController(text:widget.profile['name']??widget.user.displayName??'طالب');
  Future<void> save()async{await FirebaseFirestore.instance.collection('users').doc(widget.user.uid).set({'name':name.text.trim()},SetOptions(merge:true));if(mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('تم حفظ الاسم')));}
  @override Widget build(BuildContext context){final photo=widget.profile['photoUrl']??widget.user.photoURL??'';return Scaffold(appBar:AppBar(title:const Text('ملفي الشخصي')),body:ListView(padding:const EdgeInsets.all(22),children:[Center(child:CircleAvatar(radius:48,backgroundColor:purple,backgroundImage:photo.toString().isNotEmpty?NetworkImage(photo):null,child:photo.toString().isEmpty?const Icon(Icons.person,color:Colors.white,size:48):null)),const SizedBox(height:22),TextField(controller:name,decoration:const InputDecoration(labelText:'اسم الطالب')),const SizedBox(height:12),ListTile(leading:const Icon(Icons.school,color:purple),title:const Text('التخصص'),subtitle:Text(widget.profile['specialty']??'غير محدد')),const SizedBox(height:12),FilledButton(onPressed:save,child:const Text('حفظ التغييرات')),const SizedBox(height:12),OutlinedButton.icon(onPressed:()=>FirebaseAuth.instance.signOut(),icon:const Icon(Icons.logout),label:const Text('تسجيل الخروج'))]));}
}

class SettingsScreen extends StatelessWidget { final User user; const SettingsScreen({super.key,required this.user});
 @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('الإعدادات')),body:ListView(padding:const EdgeInsets.all(16),children:[Card(child:ListTile(leading:const Icon(Icons.workspace_premium,color:Color(0xFFD59B22),size:30),title:const Text('جامعتي المميز',style:TextStyle(fontWeight:FontWeight.bold)),subtitle:const Text('فعّل اشتراكك باستخدام كود خاص'),trailing:const Icon(Icons.chevron_left),onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>PremiumScreen(user:user))))),const Card(child:ListTile(leading:Icon(Icons.person_outline),title:Text('الحساب'),subtitle:Text('اسم وصورة حساب Google'))),const Card(child:ListTile(leading:Icon(Icons.info_outline),title:Text('حول التطبيق'),subtitle:Text('جامعتي — رفيقك في الحياة الجامعية')))]));
}

Future<String> getDeviceKey() async {
  try {
    const androidId = AndroidId();
    final id = await androidId.getId();
    if (id != null && id.isNotEmpty) return 'android:$id';
  } catch (_) {}
  try {
    final ios = await DeviceInfoPlugin().iosInfo;
    final id = ios.identifierForVendor;
    if (id != null && id.isNotEmpty) return 'ios:$id';
  } catch (_) {}
  throw Exception('تعذر قراءة معرّف الجهاز');
}

class PremiumScreen extends StatefulWidget { final User user; const PremiumScreen({super.key,required this.user}); @override State<PremiumScreen> createState()=>_PremiumScreenState(); }
class _PremiumScreenState extends State<PremiumScreen>{final code=TextEditingController();bool loading=false;bool premium=false;
 @override void initState(){super.initState();FirebaseFirestore.instance.collection('users').doc(widget.user.uid).snapshots().listen((s){if(mounted)setState(()=>premium=s.data()?['premium']==true);});}
 Future<void> activate()async{final value=code.text.trim().toUpperCase();if(value.isEmpty)return;setState(()=>loading=true);try{final device=await getDeviceKey();final result=await FirebaseFunctionsBridge.redeem(value,device);if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(result)));}catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('تعذر تفعيل الكود: $e')));}if(mounted)setState(()=>loading=false);}
 @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('جامعتي المميز')),body:ListView(padding:const EdgeInsets.all(20),children:[Container(padding:const EdgeInsets.all(22),decoration:BoxDecoration(gradient:const LinearGradient(colors:[Color(0xFFE8C46A),Color(0xFFB77B20)]),borderRadius:BorderRadius.circular(20)),child:const Column(children:[Icon(Icons.workspace_premium,color:Colors.white,size:48),SizedBox(height:10),Text('جامعتي المميز',style:TextStyle(color:Colors.white,fontWeight:FontWeight.bold,fontSize:24)),Text('مزايا إضافية للطالب الجامعي',style:TextStyle(color:Colors.white))])),const SizedBox(height:20),if(premium)const Card(child:ListTile(leading:Icon(Icons.verified,color:Colors.green),title:Text('اشتراكك المميز فعّال'))),const Text('عند شراء اشتراك، أدخل كود التفعيل الذي استلمته. الكود يرتبط بأول جهاز يتم تفعيله عليه.',style:TextStyle(height:1.7)),const SizedBox(height:14),TextField(controller:code,textCapitalization:TextCapitalization.characters,decoration:const InputDecoration(labelText:'كود التفعيل',hintText:'مثال: JAMIATI-XXXX-XXXX')),const SizedBox(height:12),FilledButton(onPressed:loading?null:activate,child:Text(loading?'جارٍ التحقق...':'تفعيل الكود')),const SizedBox(height:10),const Text('ملاحظة: لا تشارك كودك مع الآخرين. بعد ربطه بجهاز لا يمكن نقله إلى جهاز آخر.',style:TextStyle(color:Colors.black54))]));}

class FirebaseFunctionsBridge {
 static Future<String> redeem(String code,String deviceId) async {
   // Uses the callable Cloud Function deployed with the Firebase project.
   final callable=FirebaseFunctions.instance.httpsCallable('redeemPremiumCode');
   final response=await callable.call({'code':code,'deviceId':deviceId});
   return response.data['message'] as String? ?? 'تم تفعيل الاشتراك بنجاح';
 }
}

class HomeScreen extends StatelessWidget {
 final String name; final List<String> summaries; final String specialty;
 const HomeScreen({super.key,required this.name,required this.summaries,required this.specialty});
 @override Widget build(BuildContext context)=>ListView(padding:const EdgeInsets.all(18),children:[
  StudentStats(specialty:specialty),const SizedBox(height:14),
  Container(padding:const EdgeInsets.all(22),decoration:BoxDecoration(gradient:const LinearGradient(colors:[purple,darkPurple]),borderRadius:BorderRadius.circular(24)),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('أهلاً $name 👋',style:const TextStyle(color:Colors.white,fontSize:22,fontWeight:FontWeight.bold)),const SizedBox(height:8),const Text('خلّ دراستك أسهل ويا جامعتي',style:TextStyle(color:Colors.white70)),const SizedBox(height:12),const Text('مساعدك الدراسي',style:TextStyle(color:Colors.white))])),
  const SizedBox(height:22),const Text('شنو تحتاج اليوم؟',style:TextStyle(fontSize:19,fontWeight:FontWeight.bold)),const SizedBox(height:12),
  const Wrap(spacing:10,runSpacing:10,children:[FeatureCard(icon:Icons.description,title:'لخّص ملزمتك',color:purple),FeatureCard(icon:Icons.fact_check,title:'أنشئ أسئلة',color:Color(0xFF269C83)),FeatureCard(icon:Icons.chat,title:'اسأل المساعد',color:Color(0xFFDB8B38)),FeatureCard(icon:Icons.event_note,title:'نظّم وقتك',color:Color(0xFF4388D6))]),
  const SizedBox(height:20),const Text('ملخصاتك المحفوظة',style:TextStyle(fontSize:18,fontWeight:FontWeight.bold)),
  if(summaries.isEmpty)const Padding(padding:EdgeInsets.all(16),child:Text('ما عندك ملخصات بعد')),
  ...summaries.map((s)=>Card(child:ListTile(leading:const Icon(Icons.article,color:purple),title:Text(s))))
 ]);
}

class StudentStats extends StatelessWidget {
 final String specialty; const StudentStats({super.key,required this.specialty});
 @override Widget build(BuildContext context)=>StreamBuilder<DocumentSnapshot<Map<String,dynamic>>>(
  stream:FirebaseFirestore.instance.collection('public_stats').doc('students').snapshots(),
  builder:(context,snapshot){final data=snapshot.data?.data()??{};final by=Map<String,dynamic>.from(data['bySpecialty']??{});final total=(data['total'] as num?)?.toInt()??0;final count=(by[specialty] as num?)?.toInt()??0;
   return Row(children:[Expanded(child:_StatCard(title:'طلاب جامعتي',count:total,icon:Icons.groups,color:purple)),const SizedBox(width:10),Expanded(child:_StatCard(title:specialty,count:count,icon:Icons.school,color:const Color(0xFF269C83)))]);
  });
}
class _StatCard extends StatelessWidget {final String title;final int count;final IconData icon;final Color color;const _StatCard({required this.title,required this.count,required this.icon,required this.color});
 @override Widget build(BuildContext context)=>Container(padding:const EdgeInsets.all(15),decoration:BoxDecoration(color:Colors.white,borderRadius:BorderRadius.circular(18)),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Icon(icon,color:color,size:26),const SizedBox(height:8),Text('$count',style:const TextStyle(fontSize:25,fontWeight:FontWeight.w900)),Text(title,maxLines:1,overflow:TextOverflow.ellipsis,style:const TextStyle(color:Colors.black54,fontSize:12))]));}

class FeatureCard extends StatelessWidget { final IconData icon; final String title; final Color color; const FeatureCard({super.key,required this.icon,required this.title,required this.color}); @override Widget build(BuildContext context)=>Container(width:MediaQuery.sizeOf(context).width/2-24,padding:const EdgeInsets.all(16),decoration:BoxDecoration(color:Colors.white,borderRadius:BorderRadius.circular(18)),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[CircleAvatar(backgroundColor:color.withOpacity(.12),child:Icon(icon,color:color)),const SizedBox(height:10),Text(title,style:const TextStyle(fontWeight:FontWeight.bold))])); }

class SummarizeScreen extends StatefulWidget { final ValueChanged<String> onSave; const SummarizeScreen({super.key,required this.onSave}); @override State<SummarizeScreen> createState()=>_SummarizeScreenState(); }
class _SummarizeScreenState extends State<SummarizeScreen>{final title=TextEditingController(), content=TextEditingController();String result='';void make(){final t=content.text.trim();if(t.length<20){ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('أدخل نصاً أطول للتجربة')));return;}final sentences=t.split(RegExp(r'(?<=[.!؟])\s+'));setState(()=>result='ملخص تجريبي — ${title.text.trim().isEmpty?'ملزمتك':title.text.trim()}\n\n'+sentences.take(5).join('\n\n'));} @override Widget build(BuildContext context)=>ListView(padding:const EdgeInsets.all(18),children:[const InfoBanner(text:'الصق نص الملزمة لتجربة إنشاء ملخص مبدئي. هذه النسخة لا تستخدم ذكاءً اصطناعياً أو خادماً.'),const SizedBox(height:14),TextField(controller:title,decoration:const InputDecoration(labelText:'اسم المادة')),const SizedBox(height:12),TextField(controller:content,minLines:8,maxLines:14,decoration:const InputDecoration(hintText:'الصق نص الملزمة هنا...',border:OutlineInputBorder())),const SizedBox(height:14),FilledButton(onPressed:make,child:const Text('أنشئ ملخصاً تجريبياً')),if(result.isNotEmpty) ...[const SizedBox(height:16),SelectableText(result),OutlinedButton.icon(onPressed:(){widget.onSave(title.text.trim().isEmpty?'ملخص جديد':title.text.trim());ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('تم الحفظ لهذه الجلسة')));},icon:const Icon(Icons.save),label:const Text('حفظ الملخص'))]]);}

class QuizScreen extends StatefulWidget {const QuizScreen({super.key});@override State<QuizScreen> createState()=>_QuizScreenState();}
class _QuizScreenState extends State<QuizScreen>{final topic=TextEditingController();final source=TextEditingController();String result='';void make(){if(source.text.trim().length<15){ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('اكتب موضوعاً أو الصق جزءاً من الملزمة')));return;}setState(()=>result='أسئلة تجريبية عن ${topic.text.trim().isEmpty?'الموضوع':topic.text.trim()}\n\n1. ما الفكرة الرئيسية في النص؟\n2. اذكر أهم نقطتين وردتا في النص.\n3. عرّف المصطلح الأساسي المذكور.\n4. ما الفرق بين المفاهيم الواردة؟\n5. لخّص الموضوع بأسلوبك.\n\nملاحظة: هذه أسئلة قالبية وليست مولّدة بالذكاء الاصطناعي.');} @override Widget build(BuildContext context)=>ListView(padding:const EdgeInsets.all(18),children:[const InfoBanner(text:'أدخل موضوعاً لتجربة واجهة إنشاء الأسئلة. التوليد الذكي غير مفعّل في النسخة التجريبية.'),const SizedBox(height:12),TextField(controller:topic,decoration:const InputDecoration(labelText:'اسم المادة أو الموضوع')),const SizedBox(height:12),TextField(controller:source,minLines:6,maxLines:10,decoration:const InputDecoration(hintText:'الصق جزءاً من الملزمة...',border:OutlineInputBorder())),const SizedBox(height:12),FilledButton(onPressed:make,child:const Text('أنشئ أسئلة تجريبية')),if(result.isNotEmpty)Padding(padding:const EdgeInsets.only(top:18),child:SelectableText(result,style:const TextStyle(height:1.8)))]);}

class AssistantScreen extends StatefulWidget{const AssistantScreen({super.key});@override State<AssistantScreen> createState()=>_AssistantScreenState();}
class _AssistantScreenState extends State<AssistantScreen>{final input=TextEditingController();final messages=<String>['هلا بيك! هذا مساعد تجريبي. اكتب أي سؤال حتى نختبر واجهة المحادثة.'];void send(){final q=input.text.trim();if(q.isEmpty)return;setState((){messages.add('أنت: $q');messages.add('المساعد التجريبي: وصلت رسالتك. الإجابات الذكية غير مفعّلة حالياً، وستتوفر بعد ربط خدمة الذكاء الاصطناعي.');input.clear();});} @override Widget build(BuildContext context)=>Column(children:[Expanded(child:ListView(padding:const EdgeInsets.all(16),children:messages.map((m)=>Card(child:Padding(padding:const EdgeInsets.all(14),child:Text(m,style:const TextStyle(height:1.5))))).toList())),SafeArea(top:false,child:Padding(padding:const EdgeInsets.all(12),child:Row(children:[Expanded(child:TextField(controller:input,onSubmitted:(_)=>send(),decoration:const InputDecoration(hintText:'اكتب سؤالك...',border:OutlineInputBorder()))),IconButton.filled(onPressed:send,icon:const Icon(Icons.send))]))) ]);}

class ScheduleScreen extends StatefulWidget{final List<Map<String,String>> items;final VoidCallback onChanged;const ScheduleScreen({super.key,required this.items,required this.onChanged});@override State<ScheduleScreen> createState()=>_ScheduleScreenState();}
class _ScheduleScreenState extends State<ScheduleScreen>{final subject=TextEditingController(),details=TextEditingController();void add(){if(subject.text.trim().isEmpty)return;setState(()=>widget.items.add({'subject':subject.text.trim(),'details':details.text.trim()}));widget.onChanged();subject.clear();details.clear();Navigator.pop(context);}void showAdd()=>showModalBottomSheet(context:context,isScrollControlled:true,builder:(ctx)=>Padding(padding:EdgeInsets.fromLTRB(18,20,18,MediaQuery.viewInsetsOf(ctx).bottom+20),child:Column(mainAxisSize:MainAxisSize.min,children:[const Text('إضافة موعد أو محاضرة',style:TextStyle(fontWeight:FontWeight.bold,fontSize:18)),const SizedBox(height:12),TextField(controller:subject,decoration:const InputDecoration(labelText:'المادة / الموعد')),const SizedBox(height:10),TextField(controller:details,decoration:const InputDecoration(labelText:'تفاصيل إضافية')),const SizedBox(height:12),FilledButton(onPressed:add,child:const Text('حفظ'))])));@override Widget build(BuildContext context)=>Scaffold(backgroundColor:Colors.transparent,floatingActionButton:FloatingActionButton.extended(onPressed:showAdd,icon:const Icon(Icons.add),label:const Text('إضافة موعد')),body:widget.items.isEmpty?const Center(child:Text('جدولك فارغ — أضف محاضراتك ومواعيدك')):ListView(padding:const EdgeInsets.all(16),children:List.generate(widget.items.length,(i){final d=widget.items[i];return Card(child:ListTile(leading:const Icon(Icons.event,color:purple),title:Text(d['subject']!),subtitle:Text(d['details']!),trailing:IconButton(icon:const Icon(Icons.delete_outline),onPressed:(){setState(()=>widget.items.removeAt(i));widget.onChanged();})));})));}

class InfoBanner extends StatelessWidget{final String text;const InfoBanner({super.key,required this.text});@override Widget build(BuildContext context)=>Container(padding:const EdgeInsets.all(15),decoration:BoxDecoration(color:const Color(0xFFEDE7FA),borderRadius:BorderRadius.circular(16)),child:Row(crossAxisAlignment:CrossAxisAlignment.start,children:[const Icon(Icons.info_outline,color:purple),const SizedBox(width:10),Expanded(child:Text(text,style:const TextStyle(color:darkPurple,height:1.5)))]));}
