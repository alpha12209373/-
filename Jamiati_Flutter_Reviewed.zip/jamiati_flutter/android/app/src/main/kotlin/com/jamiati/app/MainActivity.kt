package com.jamiati.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
