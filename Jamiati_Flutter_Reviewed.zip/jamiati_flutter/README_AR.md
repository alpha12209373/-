# جامعتي — تطبيق Flutter لطلاب الجامعات

تم تطوير المشروع على أساس النسخة المرفقة مع الإبقاء على الأقسام الأصلية:
- الرئيسية
- تلخيص الملازم
- الاختبارات
- المساعد الدراسي
- الجدول

وأضيفت إليها:
- تسجيل الدخول بحساب Google عبر Firebase Authentication.
- اختيار التخصص عند أول دخول وحفظه في Firestore.
- إحصائية إجمالي الطلاب وعدد طلاب التخصص من مستند إحصائي عام لا يكشف بيانات الطلاب.
- ملف شخصي بسيط (الاسم وصورة Google).
- إعدادات واشتراك «جامعتي المميز» وإدخال كود التفعيل.
- ربط كود الاشتراك بأول جهاز يتم تفعيله عليه عبر Cloud Function ومعاملة Firestore ذرية.
- دالة إدارية لإنشاء أكواد الاشتراك، ولا تعمل إلا لحساب يحمل custom claim باسم `admin=true`.

ملاحظة: الملف المضغوط الأصلي كان يحتوي على مجلد `lib` و`functions` فقط، ولا يحتوي على مجلدات المنصات `android/` و`ios/`. إذا لم تكن لديك هذه المجلدات، أنشئها من داخل مجلد المشروع بالأمر `flutter create --platforms=android,ios .` قبل إعداد Firebase.

## 1) إعداد Firebase (مطلوب قبل التشغيل)

1. أنشئ مشروعاً من Firebase Console.
2. أضف تطبيق Android بالـ applicationId نفسه الموجود في `android/app/build.gradle` أو `android/app/build.gradle.kts`، ثم نزّل `google-services.json` وضعه في `android/app/`.
3. أضف تطبيق iOS ونزّل `GoogleService-Info.plist` وضعه في `ios/Runner/`.
4. فعّل Authentication ثم Google provider.
5. أنشئ Cloud Firestore database.
6. ثبّت FlutterFire CLI وشغّل `flutterfire configure` من مجلد المشروع، أو تأكد من إعداد ملفات Firebase الأصلية على Android وiOS. تهيئة التطبيق الحالية تستخدم `Firebase.initializeApp()` مع إعدادات المنصة.
7. في إعداد Google Sign-In على Android، أضف SHA-1 وSHA-256 من نسخة debug/release إلى إعدادات تطبيق Android في Firebase ثم نزّل `google-services.json` من جديد وضعه في `android/app/` مع استبدال القديم. ملف المشروع المرفق حالياً يحتوي `oauth_client` فارغاً، لذلك تفعيل Google من Firebase وحده لا يكفي لضمان نجاح تسجيل الدخول؛ يجب إكمال بصمات التوقيع وتنزيل الملف المحدّث.
8. تأكد أن بريد الدعم اختير عند تفعيل Google provider. لا تشارك ملف إعدادات أو مفاتيح خاصة خارج مشروعك.

### إعداد Google Sign-In (مهم)
- من Firebase Console افتح Project settings ثم تطبيق Android `com.jamiati.app`.
- أضف بصمتي SHA-1 وSHA-256 لنسخة التطوير، ثم احفظ.
- نزّل `google-services.json` الجديد واستبدل الملف الموجود في `android/app/`.
- إذا وقّعت نسخة Release بمفتاح مختلف، أضف بصمات ذلك المفتاح أيضاً.

### تفعيل ميزات الذكاء الاصطناعي
- الدالة `generateStudyContent` موجودة في `functions/index.js` لكنها لا تزال تحتاج مفتاح OpenAI محفوظاً كسِرّ في Firebase Functions.
- من مجلد المشروع نفّذ: `firebase functions:secrets:set OPENAI_API_KEY` ثم أدخل المفتاح عند المطالبة.
- انشر الوظائف: `firebase deploy --only functions`.
- لا تضع مفتاح OpenAI داخل تطبيق Flutter أو داخل مستودع عام.
- واجهات التلخيص والاختبارات والمساعد في هذه النسخة ما زالت تجريبية ولا تستدعي الدالة السحابية تلقائياً؛ لا تعتبرها ميزات AI عاملة قبل ربط الواجهات واختبارها.

### قاعدة البيانات
- أنشئ Cloud Firestore في Firebase Console قبل أول تسجيل دخول؛ التطبيق يقرأ ويكتب مستند المستخدم مباشرة.
- انشر قواعد الحماية: `firebase deploy --only firestore:rules`.
- بعد نشر الدالة الإحصائية، يلزم إنشاء/تهيئة مستند `public_stats/students` للحسابات الموجودة مسبقاً حتى لا تبدأ الأرقام من الصفر بشكل مضلل.

## 2) تشغيل Flutter

```bash
flutter pub get
flutter run
```

## 3) نشر قواعد Firestore والوظائف السحابية

من جذر المشروع، بعد تثبيت Firebase CLI وربط المشروع:

```bash
firebase deploy --only firestore:rules,functions
```

تأكد من إعداد `firebase.json` وتهيئة مشروع Firebase عبر `firebase init` إذا لم تكن موجودة.

## 4) إنشاء أكواد المميز (للمالك فقط)

الدالة `createPremiumCodes` تنشئ الأكواد ولا تسمح إلا لحساب Firebase Auth الذي عيّن له المالك custom claim باسم `admin: true`. لا تضع مفتاح Admin SDK داخل تطبيق الهاتف. عيّن الصلاحية من بيئة موثوقة باستخدام Firebase Admin SDK، ثم استدعِ الدالة من لوحة إدارة خاصة أو أداة آمنة. تقبل الدالة `count` و`durationDays` وتعيد قائمة الأكواد.

مثال إنشاء 20 كوداً لمدة 30 يوماً من أداة الإدارة الآمنة:

```js
await getAuth().setCustomUserClaims(uid, { admin: true });
// بعد إعادة تسجيل الدخول وتجديد ID token، استدعِ createPremiumCodes:
// { count: 20, durationDays: 30 }
```

كل كود يُنشأ مرة واحدة، ويُحجز لأول حساب وجهاز يستخدمه. لا يمكن تفعيله على جهاز ثانٍ. تغيير/إعادة ضبط الجهاز قد يغيّر معرفه، لذلك لا تعد المستخدم بإمكانية نقل الكود تلقائياً.

## 5) ملاحظات مهمة

- الأقسام الأصلية محفوظة كما هي بوصفها نماذج تجريبية؛ الملخص والأسئلة والمساعد لا تزال بحاجة إلى ربط خدمة التوليد الموجودة في `functions/index.js` حتى تصبح ميزات ذكاء اصطناعي فعلية.
- إحصائيات الطلاب تبدأ بالظهور بعد نشر `updateStudentCounts`، وتُحدّث عند إنشاء/تعديل/حذف ملف طالب. الحسابات القديمة الموجودة قبل نشر الدالة تحتاج إلى تهيئة أولية لمستند `public_stats/students`.
- صورة الملف الشخصي مأخوذة من صورة حساب Google. تغييرها من داخل التطبيق غير مضاف في هذه النسخة.
- لا يحتوي المشروع على ملفات Firebase السرية أو مفاتيح مشروعك؛ يجب إضافتها من حساب Firebase الخاص بك.
- حماية ربط الجهاز تعتمد على معرّف Android ID أو iOS Vendor ID المرسل من التطبيق. لتقوية الحماية ضد التطبيقات المعدّلة أو تزوير المعرّف، فعّل Firebase App Check (Play Integrity على Android وDeviceCheck/App Attest على iOS) قبل البيع التجاري.
